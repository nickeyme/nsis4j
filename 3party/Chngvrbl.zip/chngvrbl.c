#include <windows.h>
#include "chngvrbl.h"

HINSTANCE g_hInstance;

HWND g_hwndParent;

unsigned int myatoi(char *s);

void __declspec(dllexport) changeVariable(HWND hwndParent, int string_size, 
                                      char *variables, stack_t **stacktop)
{
  g_hwndParent=hwndParent;

  CHNGVRBL_INIT();

  // Usage:

  // Push $TEMPDIR
  // Push 25 ; $PLUGINSDIR
  // CallInstDLL "$TEMPDIR\chngvrbl.dll" changeVariable

  // or

  // chngvrbl::changeVariable 25 $TEMPDIR

  // The second option could only be used if you wanted to change
  // the $PLUGINSDIR after it was already set and being used.

  {
    char buf[1024];
	int  e=-1;
    //wsprintf(buf,"$PLUGINSDIR=%s\n",getuservariable(INST_PLUGINSDIR));
    //MessageBox(g_hwndParent,buf,0,MB_OK);

	popstring(buf);
	//MessageBox(g_hwndParent,buf,0,MB_OK);
	e = myatoi(buf);
	popstring(buf);
	//MessageBox(g_hwndParent,buf,0,MB_OK);

	setuservariable(e, buf);

	//wsprintf(buf,"$PLUGINSDIR=%s\n",getuservariable(INST_PLUGINSDIR));
    //MessageBox(g_hwndParent,buf,0,MB_OK);
  }
}

BOOL WINAPI DllMain(HANDLE hInst, ULONG ul_reason_for_call, LPVOID lpReserved)
{
  g_hInstance=hInst;
	return TRUE;
}

unsigned int myatoi(char *s)
{
  unsigned int v=0;

  for (;;)
  {
    unsigned int c=*s++;
    if (c >= '0' && c <= '9') c-='0';
    else break;
    v*=10;
    v+=c;
  }
  return v;
}
